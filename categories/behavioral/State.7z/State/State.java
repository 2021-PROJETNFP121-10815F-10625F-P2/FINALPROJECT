package categories.behavioral.State;

public interface State {
 
    public void insertMoney();
    public void ejectMoney();
    public void turnCrank();
    public void dispense();
}
